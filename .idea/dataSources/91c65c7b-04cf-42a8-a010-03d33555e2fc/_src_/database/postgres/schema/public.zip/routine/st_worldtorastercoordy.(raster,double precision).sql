create function st_worldtorastercoordy(rast raster, yw double precision) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT rowy FROM _st_worldtorastercoord($1, NULL, $2)
$$;
