create function st_polygonfromtext(text, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_PolyFromText($1, $2)
$$;
