create function st_polygon(geometry, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_SetSRID(ST_MakePolygon($1), $2)

$$;
