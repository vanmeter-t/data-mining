create function st_multipointfromwkb(bytea, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1,$2)) = 'MULTIPOINT'
	THEN ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;
