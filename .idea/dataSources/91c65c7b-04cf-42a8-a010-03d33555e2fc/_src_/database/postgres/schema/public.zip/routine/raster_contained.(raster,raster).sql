create function raster_contained(raster, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1::geometry @ $2::geometry
$$;
