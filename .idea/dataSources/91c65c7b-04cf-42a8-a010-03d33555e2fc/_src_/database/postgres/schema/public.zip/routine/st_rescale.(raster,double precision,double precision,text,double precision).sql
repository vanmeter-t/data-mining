create function st_rescale(rast raster, scalex double precision, scaley double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) returns raster
STABLE
LANGUAGE SQL
AS $$
SELECT _st_gdalwarp($1, $4, $5, NULL, $2, $3)
$$;
