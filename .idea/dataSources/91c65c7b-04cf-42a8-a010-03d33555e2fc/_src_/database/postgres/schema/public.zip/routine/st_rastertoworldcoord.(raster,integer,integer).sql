create function st_rastertoworldcoord(rast raster, columnx integer, rowy integer, OUT longitude double precision, OUT latitude double precision) returns record
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT longitude, latitude FROM _st_rastertoworldcoord($1, $2, $3)
$$;
