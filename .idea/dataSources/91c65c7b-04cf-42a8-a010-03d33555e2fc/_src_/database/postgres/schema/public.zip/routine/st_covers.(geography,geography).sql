create function st_covers(geography, geography) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $1 && $2 AND _ST_Covers($1, $2)
$$;
