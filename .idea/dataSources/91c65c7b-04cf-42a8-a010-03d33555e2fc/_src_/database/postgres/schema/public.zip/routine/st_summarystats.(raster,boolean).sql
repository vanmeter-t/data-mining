create function st_summarystats(rast raster, exclude_nodata_value boolean) returns summarystats
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT _st_summarystats($1, 1, $2, 1)
$$;
