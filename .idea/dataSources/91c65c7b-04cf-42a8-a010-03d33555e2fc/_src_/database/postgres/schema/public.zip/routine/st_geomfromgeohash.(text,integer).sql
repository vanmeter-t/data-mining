create function st_geomfromgeohash(text, integer DEFAULT NULL::integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CAST(ST_Box2dFromGeoHash($1, $2) AS geometry);
$$;
