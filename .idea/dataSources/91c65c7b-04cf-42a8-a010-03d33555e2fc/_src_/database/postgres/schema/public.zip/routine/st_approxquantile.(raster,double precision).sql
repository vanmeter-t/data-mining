create function st_approxquantile(rast raster, quantile double precision) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT (_st_quantile($1, 1, TRUE, 0.1, ARRAY[$2]::double precision[])).value
$$;
