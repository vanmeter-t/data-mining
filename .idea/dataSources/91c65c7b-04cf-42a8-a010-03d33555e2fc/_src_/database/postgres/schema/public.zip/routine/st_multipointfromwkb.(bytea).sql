create function st_multipointfromwkb(bytea) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1)) = 'MULTIPOINT'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END

$$;
