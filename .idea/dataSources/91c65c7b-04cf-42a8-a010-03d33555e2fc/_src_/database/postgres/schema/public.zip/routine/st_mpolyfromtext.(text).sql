create function st_mpolyfromtext(text) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1)) = 'MULTIPOLYGON'
	THEN ST_GeomFromText($1)
	ELSE NULL END

$$;
