create function st_rastertoworldcoordx(rast raster, xr integer, yr integer) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT longitude FROM _st_rastertoworldcoord($1, $2, $3)
$$;
