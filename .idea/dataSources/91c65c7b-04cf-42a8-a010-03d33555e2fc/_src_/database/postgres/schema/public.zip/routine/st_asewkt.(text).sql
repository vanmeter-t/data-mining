create function st_asewkt(text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_AsEWKT($1::geometry);
$$;
