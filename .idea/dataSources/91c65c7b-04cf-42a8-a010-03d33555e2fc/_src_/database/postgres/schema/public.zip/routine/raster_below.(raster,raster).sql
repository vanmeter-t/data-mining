create function raster_below(raster, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1::geometry <<| $2::geometry
$$;
