create function "_st_distanceuncached"(geography, geography) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT _ST_DistanceUnCached($1, $2, 0.0, true)
$$;
