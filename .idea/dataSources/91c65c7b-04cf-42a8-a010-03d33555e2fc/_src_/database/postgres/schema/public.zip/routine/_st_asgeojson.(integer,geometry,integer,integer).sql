create function "_st_asgeojson"(integer, geometry, integer, integer) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_AsGeoJson($2::geometry, $3::int4, $4::int4);
$$;
