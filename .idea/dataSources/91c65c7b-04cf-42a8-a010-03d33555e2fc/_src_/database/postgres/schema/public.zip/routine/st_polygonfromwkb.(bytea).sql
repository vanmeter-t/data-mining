create function st_polygonfromwkb(bytea) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1)) = 'POLYGON'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END

$$;
