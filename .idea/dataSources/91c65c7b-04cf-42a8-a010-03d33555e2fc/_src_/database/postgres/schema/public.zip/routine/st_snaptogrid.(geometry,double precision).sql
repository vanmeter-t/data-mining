create function st_snaptogrid(geometry, double precision) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_SnapToGrid($1, 0, 0, $2, $2)
$$;
