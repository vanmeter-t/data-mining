create function postgis_scripts_build_date() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2016-09-30 12:45:08'::text AS version
$$;
