create function st_approxsummarystats(rast raster, nband integer, sample_percent double precision) returns summarystats
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT _st_summarystats($1, $2, TRUE, $3)
$$;
