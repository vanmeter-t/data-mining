create function st_polygonfromtext(text) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_PolyFromText($1)
$$;
