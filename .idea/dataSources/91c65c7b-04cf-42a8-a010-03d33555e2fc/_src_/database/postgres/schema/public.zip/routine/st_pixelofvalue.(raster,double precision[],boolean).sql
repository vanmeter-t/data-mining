create function st_pixelofvalue(rast raster, search double precision[], exclude_nodata_value boolean DEFAULT true, OUT val double precision, OUT x integer, OUT y integer) returns SETOF record
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT val, x, y FROM st_pixelofvalue($1, 1, $2, $3)
$$;
