create function st_geomcollfromwkb(bytea, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE
	WHEN geometrytype(ST_GeomFromWKB($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;
