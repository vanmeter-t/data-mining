create function st_askml(geom geometry, maxdecimaldigits integer DEFAULT 15) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT _ST_AsKML(2, ST_Transform($1,4326), $2, null);
$$;
