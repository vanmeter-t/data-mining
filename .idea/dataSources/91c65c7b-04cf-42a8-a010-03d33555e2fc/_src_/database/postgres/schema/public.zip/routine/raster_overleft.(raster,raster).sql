create function raster_overleft(raster, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1::geometry &< $2::geometry
$$;
